## @defgroup Attributes-Airports Airports
# These are airport related classes.
# @ingroup Attributes

# classes
from .Airport import Airport

# packages
# ...
