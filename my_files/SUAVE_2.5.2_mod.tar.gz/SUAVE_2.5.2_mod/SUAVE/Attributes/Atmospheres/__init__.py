## @defgroup Attributes-Atmospheres Atmospheres
# Contains basic data for atmospheres.
# @ingroup Attributes

# classes
from .Atmosphere import Atmosphere

# packages
from . import Earth
