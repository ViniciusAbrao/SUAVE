## @defgroup Attributes-Constants Constants
# Contains basic data for atmospheres.
# @ingroup Attributes
# classes
from .Constant import Constant
from .Composition import Composition
