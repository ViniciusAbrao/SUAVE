## @defgroup Attributes-Planets Planets
# Available planets
# @ingroup Attributes
# classes
from .Planet import Planet
from .Earth import Earth
