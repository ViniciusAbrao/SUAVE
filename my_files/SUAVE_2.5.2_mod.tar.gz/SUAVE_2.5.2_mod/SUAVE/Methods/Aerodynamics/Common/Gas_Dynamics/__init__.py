## @defgroup Methods-Aerodynamics-Common-Gas_Dynamics Gas_Dymamics
# Gas Dynamics methods that are directly specified by analyses.
# @ingroup Methods-Aerodynamics

from .Oblique_Shock import oblique_shock_relations, theta_beta_mach