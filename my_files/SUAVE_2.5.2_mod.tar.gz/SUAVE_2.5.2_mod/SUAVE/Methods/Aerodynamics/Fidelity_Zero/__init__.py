## @defgroup Methods-Aerodynamics-Fidelity_Zero Fidelity_Zero
# Functions to perform low-fidelity calculations
# @ingroup Methods-Aerodynamics

from . import Lift
