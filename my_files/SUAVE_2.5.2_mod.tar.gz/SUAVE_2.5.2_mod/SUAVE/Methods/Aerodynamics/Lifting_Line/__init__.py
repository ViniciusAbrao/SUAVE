## @defgroup Methods-Aerodynamics-Lifting_Line Lifting_Line
# Functions to perform lifting line calculations
# @ingroup Methods-Aerodynamics

from .Lifting_Line import lifting_line