## @defgroup Methods-Aerodynamics-Supersonic_Zero Supersonic_Zero
# Functions to perform low-fidelity calculations including supersonics
# @ingroup Methods-Aerodynamics
from . import Drag