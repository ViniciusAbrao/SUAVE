## @defgroup Methods-Costs-Operating_Costs Operating Costs
# This is a stub for computing operating costs. The function currently does nothing.
# @ingroup Methods-Costs
from .compute_operating_costs import compute_operating_costs