## @ingroup Methods-Costs-Operating_Costs
# compute_operating_costs.py
#
# Created:  

# suave imports
from SUAVE.Core import Units,Data

# ----------------------------------------------------------------------
#  Compute operating costs
# ----------------------------------------------------------------------

## @ingroup Methods-Costs-Operating_Costs
def compute_operating_costs(vehicle):
    """ This is a stub. It is called by the default costs analysis, but does nothing."""
    pass

    return
