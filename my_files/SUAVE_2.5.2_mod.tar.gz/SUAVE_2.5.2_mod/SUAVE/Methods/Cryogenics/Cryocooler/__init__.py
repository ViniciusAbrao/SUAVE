## @defgroup Methods-Cryogenics-Cryocooler
# This contains functions that can compute rated power and mass for a cryocooler
# @ingroup Methods
from .cryocooler_model import cryocooler_model