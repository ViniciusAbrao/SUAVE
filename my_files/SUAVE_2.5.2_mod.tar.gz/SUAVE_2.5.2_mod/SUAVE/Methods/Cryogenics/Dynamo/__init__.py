## @defgroup Methods-Cryogenics-Dynamo 
# This contains functions that can compute the efficiency curve of a Dynamo
# @ingroup Methods
from .dynamo_efficiency import efficiency_curve