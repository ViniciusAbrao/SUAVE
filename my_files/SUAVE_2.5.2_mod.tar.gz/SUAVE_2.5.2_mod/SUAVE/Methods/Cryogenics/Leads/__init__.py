## @defgroup Methods-Cryogenics-Leads Leads
# This contains functions that can compute calculations associated with cryogenic leads
# @ingroup Methods
from .lead_calculations import Q_min