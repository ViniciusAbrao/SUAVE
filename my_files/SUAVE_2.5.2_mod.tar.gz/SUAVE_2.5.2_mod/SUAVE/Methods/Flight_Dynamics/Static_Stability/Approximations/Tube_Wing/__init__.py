## @defgroup Methods-Flight_Dynamics-Static_Stability-Approximations-Tube_Wing Tube_Wing
# @ingroup Methods-Flight_Dynamics-Static_Stability-Approximations

from .taw_cmalpha import taw_cmalpha
from .taw_cnbeta import taw_cnbeta