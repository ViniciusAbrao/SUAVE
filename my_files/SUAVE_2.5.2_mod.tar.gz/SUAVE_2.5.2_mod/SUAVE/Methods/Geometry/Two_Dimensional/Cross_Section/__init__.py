## @defgroup Methods-Geometry-Two_Dimensional-Cross_Section Cross Section
# Geometry functions for two dimensional cross sections.
# @ingroup Methods-Geometry-Two_Dimensional
from . import Airfoil
from . import Propulsion