## @defgroup Methods-Geometry-Two_Dimensional Two Dimensional
# Geometry functions for two dimensions
# @ingroup Methods-Geometry
from . import Cross_Section
from . import Planform