## @ingroup Methods-Missions-Segments-Hover
# Common.py
# 
# Created:  Jan 2016, E. Botero
# Modified:

# ----------------------------------------------------------------------
#  Unpack Unknowns
# ----------------------------------------------------------------------

## @ingroup Methods-Missions-Segments-Hover
def unpack_unknowns(segment):
    """
    Desempacota as incógnitas para o segmento de hover.

    Nesta versão adaptada, se 'throttle' não existir em state.unknowns,
    simplesmente não mexemos nele e evitamos o AttributeError.
    Isso é útil quando usamos a rede Lift_Cruise apenas com throttle_lift
    como incógnita.
    """

    unknowns    = segment.state.unknowns
    conditions  = segment.state.conditions

    # 1) THROTTLE "FORWARD" (pode não existir para hover com Lift_Cruise)
    if hasattr(unknowns, 'throttle'):
        throttle = unknowns.throttle
        # garante formato 2D (N,1) se vier em 1D
        import numpy as np
        throttle = np.atleast_2d(throttle)
        if throttle.shape[0] == 1 and conditions.frames.inertial.time.shape[0] > 1:
            # espalha ao longo dos pontos de controle, se necessário
            throttle = np.repeat(throttle, conditions.frames.inertial.time.shape[0], axis=0)
        conditions.propulsion.throttle = throttle

    # 2) THROTTLE LIFT (este normalmente é criado pelo Lift_Cruise)
    if hasattr(unknowns, 'throttle_lift'):
        throttle_lift = unknowns.throttle_lift
        import numpy as np
        throttle_lift = np.atleast_2d(throttle_lift)
        if throttle_lift.shape[0] == 1 and conditions.frames.inertial.time.shape[0] > 1:
            throttle_lift = np.repeat(throttle_lift, conditions.frames.inertial.time.shape[0], axis=0)
    else:
        # fallback: se não houver unknowns.throttle_lift,
        # tenta reaproveitar algum valor em conditions.
        if hasattr(conditions.propulsion, 'throttle_lift'):
            throttle_lift = conditions.propulsion.throttle_lift
        elif hasattr(conditions.propulsion, 'throttle'):
            throttle_lift = conditions.propulsion.throttle
        else:
            import numpy as np
            npts = conditions.frames.inertial.time.shape[0]
            throttle_lift = np.zeros((npts, 1))

    conditions.propulsion.throttle_lift = throttle_lift


# ----------------------------------------------------------------------
#  Residual Total Forces
# ----------------------------------------------------------------------

## @ingroup Methods-Missions-Segments-Hover
def residual_total_forces(segment):
    """ Calculates a residual based on forces
    
        Assumptions:
        The vehicle is not accelerating, doesn't use gravity. Only vertical forces
        
        Inputs:
            state.conditions:
                frames.inertial.total_force_vector [Newtons]
            
        Outputs:
            state.residuals.forces [meters/second^2]

        Properties Used:
        N/A
                                
    """            
    
    FT = segment.state.conditions.frames.inertial.total_force_vector

    # vertical
    segment.state.residuals.force[:,0] = FT[:,2]

    return
    
    
 
    
    
