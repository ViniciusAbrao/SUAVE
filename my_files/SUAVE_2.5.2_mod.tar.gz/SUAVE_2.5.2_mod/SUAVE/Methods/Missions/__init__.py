## @defgroup Methods-Missions Missions
# Mission methods contain the functions for setting up and solving a mission.
# @ingroup Methods

from . import Segments