## @defgroup Methods-Noise.Boom Boom
# Description
# @ingroup Methods

from . import lift_equivalent_area