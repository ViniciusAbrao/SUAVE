## @defgroup Methods-Power-Fuel_Cell Fuel_Cell
# Fuel_Cell methods contain the functions for the fuel cell analyses.
# @ingroup Methods-Power
from . import Discharge
from . import Sizing