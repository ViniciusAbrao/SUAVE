## @defgroup Methods-Power-Turboelectric-Discharge Discharge
# Functions to evaluate the use of a turboelectric powertrain to provide electric power.
# @ingroup Methods-Power-Turboelectric

from .zero_fidelity import zero_fidelity
