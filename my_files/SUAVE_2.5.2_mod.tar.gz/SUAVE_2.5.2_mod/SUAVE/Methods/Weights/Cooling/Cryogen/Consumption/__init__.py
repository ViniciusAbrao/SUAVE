## @defgroup Methods-Cooling-Cryogen-Consumption Consumption
# Functions to evaluate the use of cryogen to provide cooling power.
# @ingroup Methods-Cooling-Cryogen

from .Coolant_use import Coolant_use
