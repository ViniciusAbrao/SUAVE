## @defgroup Methods-Cooling-Cryogen Cryogen
# Cooling by liquid (or gaseous) cryogen.
# @ingroup Methods-Cooling
from . import Consumption