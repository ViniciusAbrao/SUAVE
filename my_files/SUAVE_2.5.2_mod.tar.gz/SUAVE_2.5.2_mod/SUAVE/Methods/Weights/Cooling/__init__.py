## @defgroup Methods-Weights-Cooling Cooling
# Cooling methods contain the functions for cryogenic systems such as Cryocoolers and cryogen cooling.
# @ingroup Methods

from . import Cryogen
