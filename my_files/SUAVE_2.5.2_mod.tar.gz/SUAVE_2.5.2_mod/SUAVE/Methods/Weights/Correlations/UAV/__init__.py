## @defgroup Methods-Weights-Correlations-UAV UAV
# Provides structural weight correlations for UAVs
# @ingroup Methods-Weights-Correlations

from .empty import empty