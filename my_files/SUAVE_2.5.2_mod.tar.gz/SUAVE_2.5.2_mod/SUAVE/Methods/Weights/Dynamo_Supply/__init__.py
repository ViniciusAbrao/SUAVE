## @defgroup Methods-Weights-Dyanmo_Supply Dynamo_Supply
#Dynamo methods contain the functions for Dynamos
# @ingroup Methods

from .dynamo_supply_mass_estimation import dynamo_supply_mass_estimation