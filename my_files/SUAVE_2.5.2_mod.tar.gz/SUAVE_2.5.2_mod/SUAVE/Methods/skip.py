## @ingroup Methods
def skip(*args,**kwarg):
    """This method can be used to replace default functions when
    no action is desired instead.

    Assumptions:
    N/A

    Source:
    N/A

    Inputs:
    None

    Outputs:
    None

    Properties Used:
    N/A
    """          
    pass
